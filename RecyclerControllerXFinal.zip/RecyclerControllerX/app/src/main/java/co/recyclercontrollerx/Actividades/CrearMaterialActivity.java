package co.recyclercontrollerx.Actividades;

import androidx.appcompat.app.AppCompatActivity;
import co.recyclercontrollerx.R;

import android.os.Bundle;

public class CrearMaterialActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_material);
    }
}