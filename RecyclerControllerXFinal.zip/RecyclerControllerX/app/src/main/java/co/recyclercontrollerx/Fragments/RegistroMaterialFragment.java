package co.recyclercontrollerx.Fragments;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import java.util.ArrayList;

import co.recyclercontrollerx.Clases.ConexionSQLiteHelper;
import co.recyclercontrollerx.Clases.Utilidadess;
import co.recyclercontrollerx.Clases.vo.materialVo;
import co.recyclercontrollerx.Interfaces.IComunicaAppPrincipal;

import co.recyclercontrollerx.R;


public class RegistroMaterialFragment extends Fragment {

    View vista;
    Activity actividad;
    IComunicaAppPrincipal iComunicaFragments;
    ImageButton btnAgregar;
    RecyclerView recyclerViewMateriales;
    ArrayList <materialVo>  listaMateriales;
    ConexionSQLiteHelper conexion;


    public RegistroMaterialFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        vista = inflater.inflate(R.layout.fragment_registro_material, container, false);
       /* conexion =new ConexionSQLiteHelper(actividad, Utilidadess.NOMBRE_BD,null,1);
        listaMateriales = new ArrayList<>();
        recyclerViewMateriales = vista.findViewById(R.id.recyclerManana);
        recyclerViewMateriales.setLayoutManager(new LinearLayoutManager(this.actividad));
        recyclerViewMateriales.setHasFixedSize(true); //error?

        consultarListaMateriales(); */
        return vista;
    }

    private void consultarListaMateriales()
    {
        SQLiteDatabase db = conexion.getReadableDatabase();
        materialVo material = null;
        Cursor cursor =db.rawQuery("SELECT * FROM "+ Utilidadess.TABLA_MATERIAL,null);
        while (cursor.moveToNext())
        {
            material = new materialVo();
            material.setNombreMaterial(cursor.getString(0));
            material.setTipoMaterial(cursor.getString(1));
            material.setCantidadMaterial(cursor.getInt(2));

            listaMateriales.add(material);
        }
    }
}