package co.recyclercontrollerx.Interfaces;

public interface IComunicaAppPrincipal
{
    public  void mostrarCategorias();
    public void crearPlastico();
    public void crearVidrio();
    public void crearPapel();
    public void crearOrganico();
    public void rellenarMaterial();
}
